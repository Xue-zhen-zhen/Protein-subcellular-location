# -*- coding: utf-8 -*-
"""__init__.py.py: short description


Author -- Michael Widrich
Created on -- 2017-03-01
Contact -- michael.widrich@jku.at

long description


=======  ==========  =================  ================================
Version  Date        Author             Description
0.1      2017-03-01  Michael Widrich    -
=======  ==========  =================  ================================

"""