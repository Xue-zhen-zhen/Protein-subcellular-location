NOTE:
This part you can available the code in  https://github.com/ml-jku/gapnet-pl if you not understand.