This code is tested in Matlab R2019a in WINDOWS 10 64 Bit.

You should:
1、Download the three datasets and store it in the ./part1/data/1_images/, ./part2/data/1_images/ and  ./part4/data/ folder.
2、Run MainProcess.m to completed dataset download and generate the results of our paper.