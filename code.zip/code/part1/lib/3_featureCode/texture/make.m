mex -O -c ml_texture.c
mex -O -c cvip_pgmtexture.c
mex -O ml_texture.obj cvip_pgmtexture.obj
